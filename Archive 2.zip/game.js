
/**
 * ============================================================================
 * DUCK HUNT CV - LOGIC EXPLANATION (V2 - LEVEL SYSTEM)
 * ============================================================================
 * 
 * 1. COMPUTER VISION MAPPING:
 *    - Sensitivity: 1.3x amplification.
 *    - Smoothing (LERP): 0.6 interpolation for stability.
 * 
 * 2. GESTURE DETECTION:
 *    - Pinch: Distance between thumb tip and index tip < 0.08 units.
 * 
 * 3. LEVEL & STRIKE SYSTEM (NEW):
 *    - STRIKES: If a duck's timer runs out, it flees (flies up). 
 *      Miss 3 ducks = Game Over.
 *    - LEVELS: Every 10 ducks shot, you level up.
 *      - Level 2+: More ducks spawn simultaneously.
 *      - Level 2+: Duck flight speed increases.
 *      - Level 2+: Duck "Kill Timer" gets shorter (less time to react).
 * 
 * 4. DUCK TIMER:
 *    - Each duck has a "lifeTime" (e.g. 8 seconds).
 *    - We render a small timer bar above the duck.
 * ============================================================================
 */

import {
    HandLandmarker,
    FilesetResolver
} from "https://cdn.skypack.dev/@mediapipe/tasks-vision@0.10.0";

class DuckHuntGame {
    constructor() {
        // Elements
        this.canvas = document.getElementById('gameCanvas');
        this.ctx = this.canvas.getContext('2d');
        this.cvOverlay = document.getElementById('cv-overlay');
        this.cvCtx = this.cvOverlay.getContext('2d');
        this.video = document.getElementById('webcam');
        this.crosshair = document.getElementById('crosshair');

        // HUD
        this.scoreElement = document.getElementById('score');
        this.roundElement = document.getElementById('round');
        this.ammoDisplay = document.getElementById('ammo-display');
        this.strikeDisplay = document.getElementById('strike-display');
        this.timerElement = document.getElementById('round-timer');

        // Menu Elements
        this.menuOverlay = document.getElementById('menu-overlay');
        this.menuTitle = document.getElementById('menu-title');
        this.menuSubtitle = document.getElementById('menu-subtitle');
        this.menuInstructions = document.getElementById('menu-instructions');
        this.startBtn = document.getElementById('start-btn');

        // Game State
        this.score = 0;
        this.round = 1;
        this.ammo = 3;
        this.strikes = 0;
        this.ducksShotThisRound = 0;
        this.gameState = 'menu';
        this.roundStartTime = null; // Set on level start

        // Settings
        this.ducks = [];
        this.maxDucksInScene = 1; // Starts with 1
        this.baseLifeTime = 10000; // 10 seconds in ms

        // Controls
        this.handLandmarker = null;
        this.handPos = { x: 0, y: 0 };
        this.isPinching = false;
        this.lastPinchTime = 0;

        this.assets = {
            bg: new Image(),
            duck: new Image()
        };

        this.init();
    }

    async init() {
        this.resize();
        window.addEventListener('resize', () => this.resize());

        this.assets.bg.src = 'assets/background.png';
        this.assets.duck.src = 'assets/duck.png';

        await this.setupCV();

        this.startBtn.addEventListener('click', () => {
            if (this.handLandmarker) {
                if (this.gameState === 'game-over' || this.gameState === 'menu') {
                    this.resetGame();
                    this.startGame();
                }
            }
        });

        this.gameLoop();
    }

    resetGame() {
        this.score = 0;
        this.round = 1;
        this.strikes = 0;
        this.ducksShotThisRound = 0;
        this.maxDucksInScene = 1;
        this.ducks = [];
        this.ammo = 3;
        this.roundStartTime = null;
        if (this.timerElement) this.timerElement.innerText = "60";
        this.updateHUD();
    }

    async setupCV() {
        const vision = await FilesetResolver.forVisionTasks(
            "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.0/wasm"
        );
        this.handLandmarker = await HandLandmarker.createFromOptions(vision, {
            baseOptions: {
                modelAssetPath: `https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task`,
                delegate: "GPU"
            },
            runningMode: "VIDEO",
            numHands: 1
        });

        document.getElementById('status-msg').innerText = "AI Ready! Ready to Hunt.";
        this.startBtn.innerText = "START HUNT";
    }

    async startGame() {
        try {
            if (!this.video.srcObject) {
                const stream = await navigator.mediaDevices.getUserMedia({ video: true });
                this.video.srcObject = stream;
            }

            this.video.addEventListener('loadeddata', () => {
                console.log("Webcam Loaded - Starting Game");
                this.gameState = 'playing';
                this.roundStartTime = performance.now();
                this.menuOverlay.style.display = 'none';
                this.crosshair.style.display = 'block';
                this.spawnIfNeeded();
            });

            if (this.video.readyState >= 2) {
                console.log("Webcam Ready - Starting Game");
                this.gameState = 'playing';
                this.roundStartTime = performance.now();
                this.menuOverlay.style.display = 'none';
                this.crosshair.style.display = 'block';
                this.spawnIfNeeded();
            }
        } catch (err) {
            console.error("Webcam blocked", err);
            document.getElementById('status-msg').innerText = "Error: Webcam access denied!";
        }
    }

    resize() {
        const container = document.getElementById('game-container');
        this.canvas.width = container.clientWidth;
        this.canvas.height = container.clientHeight;
        this.cvOverlay.width = 200;
        this.cvOverlay.height = 150;
    }

    spawnIfNeeded() {
        while (this.ducks.length < this.maxDucksInScene) {
            this.spawnDuck();
        }
    }

    spawnDuck() {
        const side = Math.random() > 0.5 ? 1 : -1;
        // The time to kill shrinks as you level up (minimum 3 seconds)
        const currentLifeTime = Math.max(3000, this.baseLifeTime - (this.round * 800));

        this.ducks.push({
            id: Date.now() + Math.random(),
            x: side === 1 ? -100 : this.canvas.width + 100,
            y: this.canvas.height * 0.7 - Math.random() * (this.canvas.height * 0.4),
            targetX: Math.random() * this.canvas.width,
            targetY: Math.random() * (this.canvas.height / 2),
            speed: 2 + (Math.random() * 2) + (this.round * 0.6), // Speed increases per round
            status: 'flying',
            frame: 0,
            direction: side,
            timer: 0,
            spawnTime: performance.now(),
            lifeTime: currentLifeTime,
            fleeing: false
        });
    }

    gameOver() {
        this.gameState = 'game-over';
        this.menuOverlay.style.display = 'flex';
        this.menuTitle.innerHTML = "GAME OVER";
        this.menuSubtitle.innerText = `Final Score: ${this.score}`;
        this.menuInstructions.innerHTML = `You missed too many ducks!<br>Level Reached: ${this.round}`;
        this.startBtn.innerText = "TRY AGAIN";
        this.crosshair.style.display = 'none';
    }

    levelUp() {
        this.round++;
        this.ducksShotThisRound = 0;
        this.roundStartTime = performance.now(); // RESET TIMER

        // Every 2 levels, increase max ducks simultaneously (up to 4)
        if (this.round % 2 === 0 && this.maxDucksInScene < 4) {
            this.maxDucksInScene++;
        }

        this.updateHUD();

        // Visual feedback
        const levelMsg = document.createElement('div');
        levelMsg.style.position = 'absolute';
        levelMsg.style.top = '50%';
        levelMsg.style.left = '50%';
        levelMsg.style.transform = 'translate(-50%, -50%)';
        levelMsg.style.fontFamily = "'Press Start 2P'";
        levelMsg.style.color = '#55e6ff';
        levelMsg.style.fontSize = '3rem';
        levelMsg.style.zIndex = '1000';
        levelMsg.innerText = `LEVEL ${this.round}`;
        document.getElementById('game-container').appendChild(levelMsg);

        setTimeout(() => levelMsg.remove(), 2000);
    }

    update() {
        if (this.gameState !== 'playing') return;

        const now = performance.now();

        this.ducks.forEach((duck, index) => {
            if (duck.status === 'flying') {
                // Check Timer
                const elapsed = now - duck.spawnTime;
                if (elapsed > duck.lifeTime) {
                    duck.status = 'fleeing';
                    this.addStrike();
                }

                duck.x += (duck.targetX - duck.x) * (0.01 * duck.speed);
                duck.y += (duck.targetY - duck.y) * (0.01 * duck.speed);

                if (Math.abs(duck.x - duck.targetX) < 20) {
                    duck.targetX = Math.random() * this.canvas.width;
                    duck.targetY = Math.random() * (this.canvas.height / 2);
                }

                duck.timer++;
                if (duck.timer % 10 === 0) duck.frame = (duck.frame + 1) % 3;
            } else if (duck.status === 'hit') {
                duck.timer++;
                if (duck.timer > 20) {
                    duck.status = 'falling';
                }
            } else if (duck.status === 'falling') {
                duck.y += 25; // Speed of falling
                if (duck.y > this.canvas.height) {
                    this.ducks.splice(index, 1);
                    this.spawnIfNeeded();
                }
            } else if (duck.status === 'fleeing') {
                duck.y -= 15; // Fly up quickly
                duck.timer++;
                if (duck.timer % 5 === 0) duck.frame = (duck.frame + 1) % 3;

                if (duck.y < -100) {
                    this.ducks.splice(index, 1);
                    this.spawnIfNeeded();
                }
            }
        });

        this.processCV();
    }

    addStrike() {
        this.strikes++;
        this.updateHUD();
        if (this.strikes >= 3) {
            this.gameOver();
        }
    }

    async processCV() {
        if (this.video.readyState === 4 && this.handLandmarker) {
            const results = this.handLandmarker.detectForVideo(this.video, performance.now());
            this.cvCtx.clearRect(0, 0, 200, 150);

            if (results.landmarks && results.landmarks.length > 0) {
                const hand = results.landmarks[0];
                const palmX = hand[9].x;
                const palmY = hand[9].y;

                const sensitivity = 1.4;
                const smoothing = 0.7;

                let targetX = (0.5 + (0.5 - palmX) * sensitivity) * this.canvas.width;
                let targetY = (0.5 + (palmY - 0.5) * sensitivity) * this.canvas.height;

                targetX = Math.max(0, Math.min(this.canvas.width, targetX));
                targetY = Math.max(0, Math.min(this.canvas.height, targetY));

                this.handPos.x += (targetX - this.handPos.x) * smoothing;
                this.handPos.y += (targetY - this.handPos.y) * smoothing;

                this.crosshair.style.left = `${this.handPos.x}px`;
                this.crosshair.style.top = `${this.handPos.y}px`;

                const thumbTip = hand[4];
                const indexTip = hand[8];
                const dist = Math.sqrt(Math.pow(thumbTip.x - indexTip.x, 2) + Math.pow(thumbTip.y - indexTip.y, 2));

                if (dist < 0.09) {
                    if (!this.isPinching && performance.now() - this.lastPinchTime > 200) {
                        this.shoot();
                        this.isPinching = true;
                        this.lastPinchTime = performance.now();
                    }
                } else {
                    this.isPinching = false;
                }

                this.cvCtx.fillStyle = '#ff0000';
                hand.forEach(point => {
                    this.cvCtx.beginPath();
                    this.cvCtx.arc(point.x * 200, point.y * 150, 2, 0, Math.PI * 2);
                    this.cvCtx.fill();
                });
            }
        }
    }

    shoot() {
        if (this.ammo <= 0) return;

        this.ammo--;
        this.updateHUD();

        // Add shooting class for CSS animation
        this.crosshair.classList.add('shooting');
        setTimeout(() => this.crosshair.classList.remove('shooting'), 100);

        this.ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

        let hitMade = false;
        this.ducks.forEach(duck => {
            if (duck.status === 'flying') {
                const dX = this.handPos.x - duck.x;
                const dY = this.handPos.y - duck.y;
                const dist = Math.sqrt(dX * dX + dY * dY);

                const hitRadius = this.canvas.width * 0.08;
                if (dist < hitRadius) {
                    duck.status = 'hit';
                    duck.timer = 0;
                    this.score += 500 + (this.round * 100);
                    hitMade = true;
                    this.ducksShotThisRound++;

                    if (this.ducksShotThisRound >= 5) {
                        this.levelUp();
                    }
                }
            }
        });

        if (this.ammo === 0 && !hitMade) {
            setTimeout(() => { this.ammo = 3; this.updateHUD(); }, 1500);
        } else if (hitMade) {
            this.ammo = 3;
            this.updateHUD();
        }
    }

    updateHUD() {
        this.scoreElement.innerText = this.score.toString().padStart(6, '0');
        this.roundElement.innerText = this.round;

        // Round Countdown Timer: 60s limit
        const timeLimit = 60;

        // Auto-initialize roundStartTime if it's missing while playing
        if (this.gameState === 'playing' && !this.roundStartTime) {
            console.log("Timer Force-Started");
            this.roundStartTime = performance.now();
        }

        let remaining = timeLimit;
        if (this.roundStartTime && this.gameState === 'playing') {
            const elapsed = (performance.now() - this.roundStartTime) / 1000;
            remaining = Math.max(0, Math.ceil(timeLimit - elapsed));

            // Update the display using the cached timer element
            if (this.timerElement) {
                this.timerElement.innerText = remaining.toString().padStart(2, '0');
            }

            // Move to next level if time runs out
            if (remaining <= 0) {
                console.log("Time's up! Leveling up...");
                this.levelUp();
            }
        }

        // Bullets
        const bullets = this.ammoDisplay.querySelectorAll('.bullet');
        bullets.forEach((b, i) => {
            if (i < this.ammo) b.classList.remove('spent');
            else b.classList.add('spent');
        });

        // Strikes
        const strikes = this.strikeDisplay.querySelectorAll('span');
        strikes.forEach((s, i) => {
            if (i < this.strikes) {
                s.className = 'strike-on';
            } else {
                s.className = 'strike-off';
            }
        });
    }

    draw() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        if (this.assets.bg.complete) {
            this.ctx.drawImage(this.assets.bg, 0, 0, this.canvas.width, this.canvas.height);
        }
        this.ducks.forEach(duck => this.drawDuck(duck));
    }

    drawDuck(duck) {
        const frameWidth = this.assets.duck.width / 5;
        const frameHeight = this.assets.duck.height / 5;
        let sx = 0, sy = 0;

        if (duck.status === 'flying' || duck.status === 'fleeing') {
            sy = duck.direction === 1 ? 0 : frameHeight;
            sx = duck.frame * frameWidth;
        } else if (duck.status === 'hit') {
            sy = frameHeight * 4;
            sx = 0;
        } else if (duck.status === 'falling') {
            sy = frameHeight * 3;
            sx = (Math.floor(Date.now() / 100) % 2) * frameWidth;
        }

        const duckSize = this.canvas.width * 0.08;
        const halfSize = duckSize / 2;

        this.ctx.save();
        this.ctx.translate(duck.x, duck.y);

        // Draw Timer Bar (only when flying)
        if (duck.status === 'flying') {
            const elapsed = performance.now() - duck.spawnTime;
            const remaining = Math.max(0, 1 - (elapsed / duck.lifeTime));

            const barWidth = duckSize;
            const barHeight = 10; // Thicker bar
            const barY = -halfSize - 20; // Slightly higher

            // 1. Draw Border (White) - Makes it pop on any background
            this.ctx.strokeStyle = 'white';
            this.ctx.lineWidth = 2;
            this.ctx.strokeRect(-halfSize, barY, barWidth, barHeight);

            // 2. Draw Background (Dark)
            this.ctx.fillStyle = 'rgba(0,0,0,0.7)';
            this.ctx.fillRect(-halfSize, barY, barWidth, barHeight);

            // 3. Progress of bar (Green to Red)
            const r = Math.floor(255 * (1 - remaining));
            const g = Math.floor(255 * remaining);
            this.ctx.fillStyle = `rgb(${r},${g},0)`;
            this.ctx.fillRect(-halfSize, barY, barWidth * remaining, barHeight);
        }

        this.ctx.drawImage(this.assets.duck, sx, sy, frameWidth, frameHeight, -halfSize, -halfSize, duckSize, duckSize);
        this.ctx.restore();
    }

    gameLoop() {
        if (this.gameState === 'playing') {
            this.update();
            this.updateHUD(); // Call every frame to update the timer
        }
        this.draw();
        requestAnimationFrame(() => this.gameLoop());
    }
}

new DuckHuntGame();
