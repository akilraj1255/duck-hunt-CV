
import {
    HandLandmarker,
    FilesetResolver
} from "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.0";

class DuckHuntGame {
    constructor() {
        this.canvas = document.getElementById('gameCanvas');
        this.ctx = this.canvas.getContext('2d');
        this.cvOverlay = document.getElementById('cv-overlay');
        this.cvCtx = this.cvOverlay.getContext('2d');
        this.video = document.getElementById('webcam');
        this.crosshair = document.getElementById('crosshair');
        
        this.scoreElement = document.getElementById('score');
        this.roundElement = document.getElementById('round');
        this.ammoDisplay = document.getElementById('ammo-display');
        
        this.score = 0;
        this.round = 1;
        this.ammo = 3;
        this.gameState = 'menu'; // menu, playing, round-end, game-over
        
        this.ducks = [];
        this.maxDucks = 2;
        this.duckSpawnTimer = 0;
        
        this.handLandmarker = null;
        this.handPos = { x: 0, y: 0 };
        this.isPinching = false;
        this.lastPinchTime = 0;
        
        this.assets = {
            bg: new Image(),
            duck: new Image()
        };
        
        this.init();
    }

    async init() {
        this.resize();
        window.addEventListener('resize', () => this.resize());
        
        // Load Assets
        this.assets.bg.src = 'assets/background.png';
        this.assets.duck.src = 'assets/duck.png';
        
        await this.setupCV();
        
        document.getElementById('start-btn').addEventListener('click', () => {
            if (this.handLandmarker) {
                this.startGame();
            } else {
                document.getElementById('status-msg').innerText = "Initializing CV... Please wait.";
            }
        });

        this.gameLoop();
    }

    async setupCV() {
        const vision = await FilesetResolver.forVisionTasks(
            "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.0/wasm"
        );
        this.handLandmarker = await HandLandmarker.createFromOptions(vision, {
            baseOptions: {
                modelAssetPath: `https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task`,
                delegate: "GPU"
            },
            runningMode: "VIDEO",
            numHands: 1
        });
        
        document.getElementById('status-msg').innerText = "CV Ready! Click Initialize to start.";
        document.getElementById('start-btn').innerText = "START HUNT";
    }

    async startGame() {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ video: true });
            this.video.srcObject = stream;
            this.video.addEventListener('loadeddata', () => {
                this.gameState = 'playing';
                document.getElementById('menu-overlay').style.display = 'none';
                this.crosshair.style.display = 'block';
                this.spawnDuck();
            });
        } catch (err) {
            console.error("Webcam access denied", err);
            document.getElementById('status-msg').innerText = "Error: Webcam access required!";
        }
    }

    resize() {
        const container = document.getElementById('game-container');
        this.canvas.width = container.clientWidth;
        this.canvas.height = container.clientHeight;
        this.cvOverlay.width = 200;
        this.cvOverlay.height = 150;
    }

    spawnDuck() {
        const side = Math.random() > 0.5 ? 1 : -1;
        this.ducks.push({
            x: side === 1 ? -50 : this.canvas.width + 50,
            y: this.canvas.height - 100 - Math.random() * 200,
            targetX: Math.random() * this.canvas.width,
            targetY: Math.random() * (this.canvas.height / 2),
            speed: 2 + Math.random() * 3 + (this.round * 0.5),
            type: 'mallard',
            status: 'flying', // flying, hit, falling
            frame: 0,
            direction: side,
            timer: 0
        });
    }

    update() {
        if (this.gameState !== 'playing') return;

        // Update Ducks
        this.ducks.forEach((duck, index) => {
            if (duck.status === 'flying') {
                duck.x += (duck.targetX - duck.x) * 0.02;
                duck.y += (duck.targetY - duck.y) * 0.02;
                
                // Change targets randomly
                if (Math.abs(duck.x - duck.targetX) < 10) {
                    duck.targetX = Math.random() * this.canvas.width;
                    duck.targetY = Math.random() * (this.canvas.height / 2);
                }

                // Animation
                duck.timer++;
                if (duck.timer % 10 === 0) duck.frame = (duck.frame + 1) % 3;
            } else if (duck.status === 'hit') {
                duck.timer++;
                if (duck.timer > 30) {
                    duck.status = 'falling';
                }
            } else if (duck.status === 'falling') {
                duck.y += 10;
                if (duck.y > this.canvas.height) {
                    this.ducks.splice(index, 1);
                    if (this.ducks.length === 0) {
                        setTimeout(() => this.spawnDuck(), 1000);
                    }
                }
            }
        });

        this.processCV();
    }

    async processCV() {
        if (this.video.readyState === 4 && this.handLandmarker) {
            const results = this.handLandmarker.detectForVideo(this.video, performance.now());
            
            this.cvCtx.clearRect(0, 0, 200, 150);
            
            if (results.landmarks && results.landmarks.length > 0) {
                const hand = results.landmarks[0];
                
                // MediaPipe coordinates are 0-1
                const palmX = hand[9].x; // Middle finger base
                const palmY = hand[9].y;
                
                // Smoothed cursor movement
                const targetX = (1 - palmX) * this.canvas.width; // Flip X because webcam is mirrored
                const targetY = palmY * this.canvas.height;
                
                this.handPos.x += (targetX - this.handPos.x) * 0.3;
                this.handPos.y += (targetY - this.handPos.y) * 0.3;
                
                this.crosshair.style.transform = `translate(${this.handPos.x - 30}px, ${this.handPos.y - 30}px)`;
                
                // Gesture Detection: Pinch (Thumb tip to Index tip distance)
                const thumbTip = hand[4];
                const indexTip = hand[8];
                const dist = Math.sqrt(
                    Math.pow(thumbTip.x - indexTip.x, 2) + 
                    Math.pow(thumbTip.y - indexTip.y, 2)
                );
                
                if (dist < 0.05) {
                    if (!this.isPinching && performance.now() - this.lastPinchTime > 500) {
                        this.shoot();
                        this.isPinching = true;
                        this.lastPinchTime = performance.now();
                    }
                } else {
                    this.isPinching = false;
                }

                // Draw minimal UI on CV overlay
                this.cvCtx.fillStyle = '#55e6ff';
                hand.forEach(point => {
                    this.cvCtx.beginPath();
                    this.cvCtx.arc(point.x * 200, point.y * 150, 2, 0, Math.PI * 2);
                    this.cvCtx.fill();
                });
            }
        }
    }

    shoot() {
        if (this.ammo <= 0) return;
        
        this.ammo--;
        this.updateHUD();
        
        // Flash effect
        this.ctx.fillStyle = 'white';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        
        let hit = false;
        this.ducks.forEach(duck => {
            if (duck.status === 'flying') {
                const dist = Math.sqrt(
                    Math.pow(this.handPos.x - duck.x, 2) + 
                    Math.pow(this.handPos.y - duck.y, 2)
                );
                
                if (dist < 60) {
                    duck.status = 'hit';
                    duck.timer = 0;
                    this.score += 500;
                    hit = true;
                }
            }
        });

        if (this.ammo === 0 && !hit) {
            setTimeout(() => {
                this.ammo = 3;
                this.updateHUD();
            }, 2000);
        } else if (hit) {
            this.ammo = 3;
            this.updateHUD();
        }
    }

    updateHUD() {
        this.scoreElement.innerText = this.score.toString().padStart(6, '0');
        this.roundElement.innerText = this.round;
        
        const bullets = this.ammoDisplay.querySelectorAll('.bullet');
        bullets.forEach((b, i) => {
            if (i < this.ammo) b.classList.remove('spent');
            else b.classList.add('spent');
        });
    }

    draw() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Background
        if (this.assets.bg.complete) {
            this.ctx.drawImage(this.assets.bg, 0, 0, this.canvas.width, this.canvas.height);
        }

        // Ducks
        this.ducks.forEach(duck => {
            this.drawDuck(duck);
        });
    }

    drawDuck(duck) {
        // Simple pixel duck if sprite sheet isn't perfectly sliced
        // Using sprite sheet dimensions (assuming 5x5 grid from prompt)
        const frameWidth = this.assets.duck.width / 5;
        const frameHeight = this.assets.duck.height / 5;
        
        let sx = 0, sy = 0;
        
        if (duck.status === 'flying') {
            sy = duck.direction === 1 ? 0 : frameHeight; // Fly Left/Right rows
            sx = duck.frame * frameWidth;
        } else if (duck.status === 'hit') {
            sy = frameHeight * 4; // Hit row
            sx = 0;
        } else if (duck.status === 'falling') {
            sy = frameHeight * 3; // Fall row
            sx = (Math.floor(Date.now() / 100) % 2) * frameWidth;
        }

        this.ctx.save();
        this.ctx.translate(duck.x, duck.y);
        this.ctx.drawImage(
            this.assets.duck,
            sx, sy, frameWidth, frameHeight,
            -40, -40, 80, 80
        );
        this.ctx.restore();
    }

    gameLoop() {
        this.update();
        this.draw();
        requestAnimationFrame(() => this.gameLoop());
    }
}

new DuckHuntGame();
